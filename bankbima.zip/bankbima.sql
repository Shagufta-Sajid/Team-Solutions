-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Apr 18, 2024 at 12:53 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bankbima`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`id`, `name`, `email`, `email_verified_at`, `password`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Shagufta', 'ssajid3421@gmail.com', NULL, '$2y$12$WIQlr8LC7k3cXUbGOwzpS.A6wI9Am5d/lqFqILtWP4IT4G46.Pb0G', 0, '2024-04-15 02:22:10', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `attendences`
--

CREATE TABLE `attendences` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` int(11) NOT NULL,
  `date` date NOT NULL,
  `attend_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `entry_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `department__infos`
--

CREATE TABLE `department__infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `dept_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `department__infos`
--

INSERT INTO `department__infos` (`id`, `dept_name`, `added_at`, `updated_at`) VALUES
(1, 'Acounts', '2024-04-16 05:43:03', NULL),
(2, 'Editor', '2024-04-16 05:43:03', NULL),
(3, 'Marketing', '2024-04-16 05:43:03', NULL),
(4, 'Kitchen', '2024-04-16 05:43:03', NULL),
(5, 'Worker', '2024-04-16 05:43:03', NULL),
(6, 'Printing', '2024-04-16 05:43:03', NULL),
(7, 'Reporter', '2024-04-16 05:43:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `designations`
--

CREATE TABLE `designations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dept_id` bigint(20) UNSIGNED NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `designations`
--

INSERT INTO `designations` (`id`, `designation`, `dept_id`, `added_at`, `updated_at`) VALUES
(1, 'Junior Editor', 2, '2024-04-16 05:43:03', NULL),
(2, 'Chief Editor', 2, '2024-04-16 05:43:03', NULL),
(3, 'Marketing Chief', 3, '2024-04-16 05:43:03', NULL),
(4, 'Freelencer', 3, '2024-04-16 05:43:03', NULL),
(5, 'Cleaner', 5, '2024-04-16 05:43:03', NULL),
(6, 'Chef', 4, '2024-04-16 05:43:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `education_details`
--

CREATE TABLE `education_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `emp_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level_of_education` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `degree_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `institution_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `result` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scale` decimal(8,2) NOT NULL,
  `cgpa` decimal(8,2) NOT NULL,
  `batch` int(11) NOT NULL,
  `passing_year` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `education_details`
--

INSERT INTO `education_details` (`id`, `emp_id`, `level_of_education`, `degree_title`, `group`, `institution_name`, `result`, `scale`, `cgpa`, `batch`, `passing_year`, `created_at`, `updated_at`) VALUES
(1, 'E000000101', 'HSC', 'Higher School Certificate', 'Science', 'IPSC', 'Grade', '5.00', '3.22', 2019, 2019, NULL, NULL),
(2, 'E000000102', 'SSC', 'Secondary School Certificate', 'Science', 'BCIC', 'Grade', '5.00', '3.33', 2017, 2017, NULL, NULL),
(5, 'E000000105', 'SSC', 'Secondary School Certificate', 'Science', 'Monipur', 'Grade', '5.00', '4.90', 2015, 2015, NULL, NULL),
(6, 'E000000106', 'BA', 'Bachelor of Administration', 'Commerce', 'Women College', 'Class', '5.00', '4.00', 1990, 1990, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `experience_details`
--

CREATE TABLE `experience_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `emp_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `department` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `experience_details`
--

INSERT INTO `experience_details` (`id`, `emp_id`, `company_name`, `designation`, `start_date`, `end_date`, `department`, `company_location`, `created_at`, `updated_at`) VALUES
(1, 'E000000101', 'Software Ltd.', 'Programmer', '2022-02-22', '2023-02-23', 'Cse', 'Mirpur', NULL, NULL),
(2, 'E000000102', 'Automation Ltd.', 'Tester', '2022-06-22', '2022-11-24', 'Testing', 'Mirpur', NULL, NULL),
(5, 'E000000105', 'Software Ltd.', 'Programmer', '2021-06-21', '2021-07-13', 'Testing', 'Mirpur', NULL, NULL),
(6, 'E000000106', 'Kinder Garten School', 'Teacher', '2010-05-10', '2010-12-10', 'English', 'Cumilla', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `joining_details`
--

CREATE TABLE `joining_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `emp_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `joining_date` date NOT NULL,
  `joining_location` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `designation` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `joining_details`
--

INSERT INTO `joining_details` (`id`, `emp_id`, `joining_date`, `joining_location`, `department`, `designation`, `created_at`, `updated_at`) VALUES
(1, 'E000000101', '2024-04-01', 'Bangla Motor', 'Cse', 'Programmer', NULL, NULL),
(2, 'E000000102', '2024-04-10', 'bd', 'Testing', 'Tester', NULL, NULL),
(5, 'E000000105', '2024-01-25', 'bd', 'Testing', 'Programmer', NULL, NULL),
(6, 'E000000106', '2015-12-10', 'Mirpur', 'English', 'Teacher', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `location__infos`
--

CREATE TABLE `location__infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `division` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `district` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `upazila` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `location__infos`
--

INSERT INTO `location__infos` (`id`, `division`, `district`, `upazila`, `added_at`, `updated_at`) VALUES
(1, 'Barishal Division', 'Barguna', 'Amtali', '2024-04-16 05:43:02', NULL),
(2, 'Barishal Division', 'Barguna', 'Bamna', '2024-04-16 05:43:02', NULL),
(3, 'Barishal Division', 'Barguna', 'Barguna Sadar', '2024-04-16 05:43:02', NULL),
(4, 'Barishal Division', 'Barguna', 'Betagi', '2024-04-16 05:43:02', NULL),
(5, 'Barishal Division', 'Barguna', 'Patharghata', '2024-04-16 05:43:02', NULL),
(6, 'Barishal Division', 'Barguna', 'Taltali', '2024-04-16 05:43:02', NULL),
(7, 'Barishal Division', 'Barishal', 'Agailjhara', '2024-04-16 05:43:02', NULL),
(8, 'Barishal Division', 'Barishal', 'Babuganj', '2024-04-16 05:43:02', NULL),
(9, 'Barishal Division', 'Barishal', 'Bakerganj', '2024-04-16 05:43:02', NULL),
(10, 'Barishal Division', 'Barishal', 'Banaripara', '2024-04-16 05:43:02', NULL),
(11, 'Barishal Division', 'Barishal', 'Barishal Sadar', '2024-04-16 05:43:02', NULL),
(12, 'Barishal Division', 'Barishal', 'Gouranadi', '2024-04-16 05:43:02', NULL),
(13, 'Barishal Division', 'Barishal', 'Hizla', '2024-04-16 05:43:02', NULL),
(14, 'Barishal Division', 'Barishal', 'Mehendiganj', '2024-04-16 05:43:02', NULL),
(15, 'Barishal Division', 'Barishal', 'Muladi', '2024-04-16 05:43:02', NULL),
(16, 'Barishal Division', 'Barishal', 'Wazirpur', '2024-04-16 05:43:02', NULL),
(17, 'Barishal Division', 'Bhola', 'Bhola Sadar', '2024-04-16 05:43:02', NULL),
(18, 'Barishal Division', 'Bhola', 'Burhanuddin', '2024-04-16 05:43:02', NULL),
(19, 'Barishal Division', 'Bhola', 'Charfassion', '2024-04-16 05:43:02', NULL),
(20, 'Barishal Division', 'Bhola', 'Daulatkhan', '2024-04-16 05:43:02', NULL),
(21, 'Barishal Division', 'Bhola', 'Lalmohan', '2024-04-16 05:43:02', NULL),
(22, 'Barishal Division', 'Bhola', 'Monpura', '2024-04-16 05:43:02', NULL),
(23, 'Barishal Division', 'Bhola', 'Tazumuddin', '2024-04-16 05:43:02', NULL),
(24, 'Barishal Division', 'Jhalokathi', 'Jhalokathi Sadar', '2024-04-16 05:43:02', NULL),
(25, 'Barishal Division', 'Jhalokathi', 'Kathalia', '2024-04-16 05:43:02', NULL),
(26, 'Barishal Division', 'Jhalokathi', 'Nalchity', '2024-04-16 05:43:02', NULL),
(27, 'Barishal Division', 'Jhalokathi', 'Rajapur', '2024-04-16 05:43:02', NULL),
(28, 'Barishal Division', 'Patuakhali', 'Bauphal', '2024-04-16 05:43:02', NULL),
(29, 'Barishal Division', 'Patuakhali', 'Dashmina', '2024-04-16 05:43:02', NULL),
(30, 'Barishal Division', 'Patuakhali', 'Dumki', '2024-04-16 05:43:02', NULL),
(31, 'Barishal Division', 'Patuakhali', 'Galachipa', '2024-04-16 05:43:02', NULL),
(32, 'Barishal Division', 'Patuakhali', 'Kalapara', '2024-04-16 05:43:02', NULL),
(33, 'Barishal Division', 'Patuakhali', 'Mirjaganj', '2024-04-16 05:43:02', NULL),
(34, 'Barishal Division', 'Patuakhali', 'Patuakhali Sadar', '2024-04-16 05:43:02', NULL),
(35, 'Barishal Division', 'Patuakhali', 'Rangabali', '2024-04-16 05:43:02', NULL),
(36, 'Barishal Division', 'Pirojpur', 'Bhandaria', '2024-04-16 05:43:02', NULL),
(37, 'Barishal Division', 'Pirojpur', 'Kawkhali', '2024-04-16 05:43:02', NULL),
(38, 'Barishal Division', 'Pirojpur', 'Mathbaria', '2024-04-16 05:43:02', NULL),
(39, 'Barishal Division', 'Pirojpur', 'Nazirpur', '2024-04-16 05:43:02', NULL),
(40, 'Barishal Division', 'Pirojpur', 'Nesarabad', '2024-04-16 05:43:02', NULL),
(41, 'Barishal Division', 'Pirojpur', 'Pirojpur Sadar', '2024-04-16 05:43:02', NULL),
(42, 'Barishal Division', 'Pirojpur', 'Zianagar/Indurkani', '2024-04-16 05:43:02', NULL),
(43, 'Chattogram Division', 'Brahmanbaria', 'Akhaura', '2024-04-16 05:43:02', NULL),
(44, 'Chattogram Division', 'Brahmanbaria', 'Ashuganj', '2024-04-16 05:43:02', NULL),
(45, 'Chattogram Division', 'Brahmanbaria', 'Brahmanbaria Sadar', '2024-04-16 05:43:02', NULL),
(46, 'Chattogram Division', 'Brahmanbaria', 'Bancharampur', '2024-04-16 05:43:02', NULL),
(47, 'Chattogram Division', 'Brahmanbaria', 'Bijoynagar', '2024-04-16 05:43:02', NULL),
(48, 'Chattogram Division', 'Brahmanbaria', 'Kasba', '2024-04-16 05:43:02', NULL),
(49, 'Chattogram Division', 'Brahmanbaria', 'Nabinagar', '2024-04-16 05:43:02', NULL),
(50, 'Chattogram Division', 'Brahmanbaria', 'Nasirnagar', '2024-04-16 05:43:02', NULL),
(51, 'Chattogram Division', 'Brahmanbaria', 'Sarail', '2024-04-16 05:43:02', NULL),
(52, 'Chattogram Division', 'Bandarban', 'Alikadam', '2024-04-16 05:43:02', NULL),
(53, 'Chattogram Division', 'Bandarban', 'Bandarban Sadar', '2024-04-16 05:43:02', NULL),
(54, 'Chattogram Division', 'Bandarban', 'Lama', '2024-04-16 05:43:02', NULL),
(55, 'Chattogram Division', 'Bandarban', 'Naikhyongchari', '2024-04-16 05:43:02', NULL),
(56, 'Chattogram Division', 'Bandarban', 'Rowangchari', '2024-04-16 05:43:02', NULL),
(57, 'Chattogram Division', 'Bandarban', 'Ruma', '2024-04-16 05:43:02', NULL),
(58, 'Chattogram Division', 'Bandarban', 'Thanchi', '2024-04-16 05:43:02', NULL),
(59, 'Chattogram Division', 'Chandpur', 'Chandpur Sadar', '2024-04-16 05:43:02', NULL),
(60, 'Chattogram Division', 'Chandpur', 'Faridganj', '2024-04-16 05:43:02', NULL),
(61, 'Chattogram Division', 'Chandpur', 'Haimchar', '2024-04-16 05:43:02', NULL),
(62, 'Chattogram Division', 'Chandpur', 'Haziganj', '2024-04-16 05:43:02', NULL),
(63, 'Chattogram Division', 'Chandpur', 'Kachua', '2024-04-16 05:43:02', NULL),
(64, 'Chattogram Division', 'Chandpur', 'Matlab (Dakshin)', '2024-04-16 05:43:02', NULL),
(65, 'Chattogram Division', 'Chandpur', 'Matlab (Uttar)', '2024-04-16 05:43:02', NULL),
(66, 'Chattogram Division', 'Chandpur', 'Shahrasti', '2024-04-16 05:43:02', NULL),
(67, 'Chattogram Division', 'Chattogram', 'Anwara', '2024-04-16 05:43:02', NULL),
(68, 'Chattogram Division', 'Chattogram', 'Banskhali', '2024-04-16 05:43:02', NULL),
(69, 'Chattogram Division', 'Chattogram', 'Boalkhali', '2024-04-16 05:43:02', NULL),
(70, 'Chattogram Division', 'Chattogram', 'Chandanish', '2024-04-16 05:43:02', NULL),
(71, 'Chattogram Division', 'Chattogram', 'Fatikchari', '2024-04-16 05:43:02', NULL),
(72, 'Chattogram Division', 'Chattogram', 'Hathazari', '2024-04-16 05:43:02', NULL),
(73, 'Chattogram Division', 'Chattogram', 'Karnaphuli', '2024-04-16 05:43:02', NULL),
(74, 'Chattogram Division', 'Chattogram', 'Lohagara', '2024-04-16 05:43:02', NULL),
(75, 'Chattogram Division', 'Chattogram', 'Mirsharai', '2024-04-16 05:43:02', NULL),
(76, 'Chattogram Division', 'Chattogram', 'Patiya', '2024-04-16 05:43:02', NULL),
(77, 'Chattogram Division', 'Chattogram', 'Rangunia', '2024-04-16 05:43:02', NULL),
(78, 'Chattogram Division', 'Chattogram', 'Raojan', '2024-04-16 05:43:02', NULL),
(79, 'Chattogram Division', 'Chattogram', 'Sandwip', '2024-04-16 05:43:02', NULL),
(80, 'Chattogram Division', 'Chattogram', 'Satkania', '2024-04-16 05:43:02', NULL),
(81, 'Chattogram Division', 'Chattogram', 'Sitakunda', '2024-04-16 05:43:02', NULL),
(82, 'Chattogram Division', 'Cox\'s Bazar', 'Cox\'s Bazar Sadar', '2024-04-16 05:43:02', NULL),
(83, 'Chattogram Division', 'Cox\'s Bazar', 'Chakaria', '2024-04-16 05:43:02', NULL),
(84, 'Chattogram Division', 'Cox\'s Bazar', 'Eidgaon', '2024-04-16 05:43:02', NULL),
(85, 'Chattogram Division', 'Cox\'s Bazar', 'Kutubdia', '2024-04-16 05:43:02', NULL),
(86, 'Chattogram Division', 'Cox\'s Bazar', 'Moheskhali', '2024-04-16 05:43:02', NULL),
(87, 'Chattogram Division', 'Cox\'s Bazar', 'Pekua', '2024-04-16 05:43:02', NULL),
(88, 'Chattogram Division', 'Cox\'s Bazar', 'Ramu', '2024-04-16 05:43:02', NULL),
(89, 'Chattogram Division', 'Cox\'s Bazar', 'Teknaf', '2024-04-16 05:43:02', NULL),
(90, 'Chattogram Division', 'Cox\'s Bazar', 'Ukhiya', '2024-04-16 05:43:02', NULL),
(91, 'Chattogram Division', 'Cumilla', 'Barura', '2024-04-16 05:43:02', NULL),
(92, 'Chattogram Division', 'Cumilla', 'Brahmanpara', '2024-04-16 05:43:02', NULL),
(93, 'Chattogram Division', 'Cumilla', 'Burichong', '2024-04-16 05:43:02', NULL),
(94, 'Chattogram Division', 'Cumilla', 'Chandina', '2024-04-16 05:43:02', NULL),
(95, 'Chattogram Division', 'Cumilla', 'Chouddagram', '2024-04-16 05:43:02', NULL),
(96, 'Chattogram Division', 'Cumilla', 'Cumilla Sadar', '2024-04-16 05:43:02', NULL),
(97, 'Chattogram Division', 'Cumilla', 'Cumilla Sadar Daksin', '2024-04-16 05:43:02', NULL),
(98, 'Chattogram Division', 'Cumilla', 'Daudkandi', '2024-04-16 05:43:02', NULL),
(99, 'Chattogram Division', 'Cumilla', 'Debidwar', '2024-04-16 05:43:02', NULL),
(100, 'Chattogram Division', 'Cumilla', 'Homna', '2024-04-16 05:43:02', NULL),
(101, 'Chattogram Division', 'Cumilla', 'Laksham', '2024-04-16 05:43:02', NULL),
(102, 'Chattogram Division', 'Cumilla', 'Lalmai', '2024-04-16 05:43:02', NULL),
(103, 'Chattogram Division', 'Cumilla', 'Meghna', '2024-04-16 05:43:02', NULL),
(104, 'Chattogram Division', 'Cumilla', 'Monohorganj', '2024-04-16 05:43:02', NULL),
(105, 'Chattogram Division', 'Cumilla', 'Muradnagar', '2024-04-16 05:43:02', NULL),
(106, 'Chattogram Division', 'Cumilla', 'Nangalkot', '2024-04-16 05:43:02', NULL),
(107, 'Chattogram Division', 'Cumilla', 'Titas', '2024-04-16 05:43:02', NULL),
(108, 'Chattogram Division', 'Feni', 'Chhagalniya', '2024-04-16 05:43:02', NULL),
(109, 'Chattogram Division', 'Feni', 'Daganbhuiyan', '2024-04-16 05:43:02', NULL),
(110, 'Chattogram Division', 'Feni', 'Feni Sadar', '2024-04-16 05:43:02', NULL),
(111, 'Chattogram Division', 'Feni', 'Fulgazi', '2024-04-16 05:43:02', NULL),
(112, 'Chattogram Division', 'Feni', 'Parshuram', '2024-04-16 05:43:02', NULL),
(113, 'Chattogram Division', 'Feni', 'Sonagazi', '2024-04-16 05:43:02', NULL),
(114, 'Chattogram Division', 'Khagrachari', 'Dighinala', '2024-04-16 05:43:02', NULL),
(115, 'Chattogram Division', 'Khagrachari', 'Guimara', '2024-04-16 05:43:02', NULL),
(116, 'Chattogram Division', 'Khagrachari', 'Khagrachari Sadar', '2024-04-16 05:43:02', NULL),
(117, 'Chattogram Division', 'Khagrachari', 'Lakshmichhari', '2024-04-16 05:43:02', NULL),
(118, 'Chattogram Division', 'Khagrachari', 'Mahalchari', '2024-04-16 05:43:02', NULL),
(119, 'Chattogram Division', 'Khagrachari', 'Manikchari', '2024-04-16 05:43:02', NULL),
(120, 'Chattogram Division', 'Khagrachari', 'Matiranga', '2024-04-16 05:43:02', NULL),
(121, 'Chattogram Division', 'Khagrachari', 'Panchhari', '2024-04-16 05:43:02', NULL),
(122, 'Chattogram Division', 'Khagrachari', 'Ramgarh', '2024-04-16 05:43:02', NULL),
(123, 'Chattogram Division', 'Laxmipur', 'Kamalnagar', '2024-04-16 05:43:02', NULL),
(124, 'Chattogram Division', 'Laxmipur', 'Laxmipur Sadar', '2024-04-16 05:43:02', NULL),
(125, 'Chattogram Division', 'Laxmipur', 'Raipur', '2024-04-16 05:43:02', NULL),
(126, 'Chattogram Division', 'Laxmipur', 'Ramganj', '2024-04-16 05:43:03', NULL),
(127, 'Chattogram Division', 'Laxmipur', 'Ramgati', '2024-04-16 05:43:03', NULL),
(128, 'Chattogram Division', 'Noakhali', 'Begumganj', '2024-04-16 05:43:03', NULL),
(129, 'Chattogram Division', 'Noakhali', 'Chatkhil', '2024-04-16 05:43:03', NULL),
(130, 'Chattogram Division', 'Noakhali', 'Companiganj', '2024-04-16 05:43:03', NULL),
(131, 'Chattogram Division', 'Noakhali', 'Hatiya', '2024-04-16 05:43:03', NULL),
(132, 'Chattogram Division', 'Noakhali', 'Kabirhat', '2024-04-16 05:43:03', NULL),
(133, 'Chattogram Division', 'Noakhali', 'Noakhali Sadar', '2024-04-16 05:43:03', NULL),
(134, 'Chattogram Division', 'Noakhali', 'Senbag', '2024-04-16 05:43:03', NULL),
(135, 'Chattogram Division', 'Noakhali', 'Sonaimuri', '2024-04-16 05:43:03', NULL),
(136, 'Chattogram Division', 'Noakhali', 'Subarna Char', '2024-04-16 05:43:03', NULL),
(137, 'Chattogram Division', 'Rangamati', 'Rangamati Sadar', '2024-04-16 05:43:03', NULL),
(138, 'Chattogram Division', 'Rangamati', 'Baghaichari', '2024-04-16 05:43:03', NULL),
(139, 'Chattogram Division', 'Rangamati', 'Barkal', '2024-04-16 05:43:03', NULL),
(140, 'Chattogram Division', 'Rangamati', 'Belaichhari', '2024-04-16 05:43:03', NULL),
(141, 'Chattogram Division', 'Rangamati', 'Juraichhari', '2024-04-16 05:43:03', NULL),
(142, 'Chattogram Division', 'Rangamati', 'Kaptai', '2024-04-16 05:43:03', NULL),
(143, 'Chattogram Division', 'Rangamati', 'Kaukhali', '2024-04-16 05:43:03', NULL),
(144, 'Chattogram Division', 'Rangamati', 'Langadu', '2024-04-16 05:43:03', NULL),
(145, 'Chattogram Division', 'Rangamati', 'Nanniarchar', '2024-04-16 05:43:03', NULL),
(146, 'Chattogram Division', 'Rangamati', 'Rajasthali', '2024-04-16 05:43:03', NULL),
(147, 'Dhaka Division', 'Dhaka', 'Dhamrai', '2024-04-16 05:43:03', NULL),
(148, 'Dhaka Division', 'Dhaka', 'Dohar', '2024-04-16 05:43:03', NULL),
(149, 'Dhaka Division', 'Dhaka', 'Keraniganj', '2024-04-16 05:43:03', NULL),
(150, 'Dhaka Division', 'Dhaka', 'Nawabganj', '2024-04-16 05:43:03', NULL),
(151, 'Dhaka Division', 'Dhaka', 'Savar', '2024-04-16 05:43:03', NULL),
(152, 'Dhaka Division', 'Faridpur', 'Alfadanga', '2024-04-16 05:43:03', NULL),
(153, 'Dhaka Division', 'Faridpur', 'Bhanga', '2024-04-16 05:43:03', NULL),
(154, 'Dhaka Division', 'Faridpur', 'Boalmari', '2024-04-16 05:43:03', NULL),
(155, 'Dhaka Division', 'Faridpur', 'Charbhadrasan', '2024-04-16 05:43:03', NULL),
(156, 'Dhaka Division', 'Faridpur', 'Faridpur Sadar', '2024-04-16 05:43:03', NULL),
(157, 'Dhaka Division', 'Faridpur', 'Madhukhali', '2024-04-16 05:43:03', NULL),
(158, 'Dhaka Division', 'Faridpur', 'Nagarkanda', '2024-04-16 05:43:03', NULL),
(159, 'Dhaka Division', 'Faridpur', 'Sadarpur', '2024-04-16 05:43:03', NULL),
(160, 'Dhaka Division', 'Faridpur', 'Saltha', '2024-04-16 05:43:03', NULL),
(161, 'Dhaka Division', 'Gazipur', 'Gazipur Sadar', '2024-04-16 05:43:03', NULL),
(162, 'Dhaka Division', 'Gazipur', 'Kaliakoir', '2024-04-16 05:43:03', NULL),
(163, 'Dhaka Division', 'Gazipur', 'Kaliganj', '2024-04-16 05:43:03', NULL),
(164, 'Dhaka Division', 'Gazipur', 'Kapasia', '2024-04-16 05:43:03', NULL),
(165, 'Dhaka Division', 'Gazipur', 'Sreepur', '2024-04-16 05:43:03', NULL),
(166, 'Dhaka Division', 'Gopalganj', 'Gopalganj Sadar', '2024-04-16 05:43:03', NULL),
(167, 'Dhaka Division', 'Gopalganj', 'Kasiani', '2024-04-16 05:43:03', NULL),
(168, 'Dhaka Division', 'Gopalganj', 'Kotwalipara', '2024-04-16 05:43:03', NULL),
(169, 'Dhaka Division', 'Gopalganj', 'Muksudpur', '2024-04-16 05:43:03', NULL),
(170, 'Dhaka Division', 'Gopalganj', 'Tungipara', '2024-04-16 05:43:03', NULL),
(171, 'Dhaka Division', 'Kishoreganj', 'Austagram', '2024-04-16 05:43:03', NULL),
(172, 'Dhaka Division', 'Kishoreganj', 'Bajitpur', '2024-04-16 05:43:03', NULL),
(173, 'Dhaka Division', 'Kishoreganj', 'Bhairab', '2024-04-16 05:43:03', NULL),
(174, 'Dhaka Division', 'Kishoreganj', 'Hossainpur', '2024-04-16 05:43:03', NULL),
(175, 'Dhaka Division', 'Kishoreganj', 'Itna', '2024-04-16 05:43:03', NULL),
(176, 'Dhaka Division', 'Kishoreganj', 'Karimganj', '2024-04-16 05:43:03', NULL),
(177, 'Dhaka Division', 'Kishoreganj', 'Katiadi', '2024-04-16 05:43:03', NULL),
(178, 'Dhaka Division', 'Kishoreganj', 'Kishoreganj Sadar', '2024-04-16 05:43:03', NULL),
(179, 'Dhaka Division', 'Kishoreganj', 'Kuliarchar', '2024-04-16 05:43:03', NULL),
(180, 'Dhaka Division', 'Kishoreganj', 'Mithamoin', '2024-04-16 05:43:03', NULL),
(181, 'Dhaka Division', 'Kishoreganj', 'Nikli', '2024-04-16 05:43:03', NULL),
(182, 'Dhaka Division', 'Kishoreganj', 'Pakundia', '2024-04-16 05:43:03', NULL),
(183, 'Dhaka Division', 'Kishoreganj', 'Tarail', '2024-04-16 05:43:03', NULL),
(184, 'Dhaka Division', 'Madaripur', 'Dasar', '2024-04-16 05:43:03', NULL),
(185, 'Dhaka Division', 'Madaripur', 'Kalkini', '2024-04-16 05:43:03', NULL),
(186, 'Dhaka Division', 'Madaripur', 'Madaripur Sadar', '2024-04-16 05:43:03', NULL),
(187, 'Dhaka Division', 'Madaripur', 'Rajoir', '2024-04-16 05:43:03', NULL),
(188, 'Dhaka Division', 'Madaripur', 'Shibchar', '2024-04-16 05:43:03', NULL),
(189, 'Dhaka Division', 'Manikganj', 'Daulatpur', '2024-04-16 05:43:03', NULL),
(190, 'Dhaka Division', 'Manikganj', 'Ghior', '2024-04-16 05:43:03', NULL),
(191, 'Dhaka Division', 'Manikganj', 'Harirampur', '2024-04-16 05:43:03', NULL),
(192, 'Dhaka Division', 'Manikganj', 'Manikganj Sadar', '2024-04-16 05:43:03', NULL),
(193, 'Dhaka Division', 'Manikganj', 'Saturia', '2024-04-16 05:43:03', NULL),
(194, 'Dhaka Division', 'Manikganj', 'Shivalaya', '2024-04-16 05:43:03', NULL),
(195, 'Dhaka Division', 'Manikganj', 'Singair', '2024-04-16 05:43:03', NULL),
(196, 'Dhaka Division', 'Munshiganj', 'Gazaria', '2024-04-16 05:43:03', NULL),
(197, 'Dhaka Division', 'Munshiganj', 'Lauhajong', '2024-04-16 05:43:03', NULL),
(198, 'Dhaka Division', 'Munshiganj', 'Munshiganj Sadar', '2024-04-16 05:43:03', NULL),
(199, 'Dhaka Division', 'Munshiganj', 'Sirajdikhan', '2024-04-16 05:43:03', NULL),
(200, 'Dhaka Division', 'Munshiganj', 'Sreenagar', '2024-04-16 05:43:03', NULL),
(201, 'Dhaka Division', 'Munshiganj', 'Tongibari', '2024-04-16 05:43:03', NULL),
(202, 'Dhaka Division', 'Narayanganj', 'Araihazar', '2024-04-16 05:43:03', NULL),
(203, 'Dhaka Division', 'Narayanganj', 'Bandar', '2024-04-16 05:43:03', NULL),
(204, 'Dhaka Division', 'Narayanganj', 'Narayanganj Sadar', '2024-04-16 05:43:03', NULL),
(205, 'Dhaka Division', 'Narayanganj', 'Rupganj', '2024-04-16 05:43:03', NULL),
(206, 'Dhaka Division', 'Narayanganj', 'Sonargaon', '2024-04-16 05:43:03', NULL),
(207, 'Dhaka Division', 'Narshingdi', 'Belabo', '2024-04-16 05:43:03', NULL),
(208, 'Dhaka Division', 'Narshingdi', 'Monohardi', '2024-04-16 05:43:03', NULL),
(209, 'Dhaka Division', 'Narshingdi', 'Narshingdi Sadar', '2024-04-16 05:43:03', NULL),
(210, 'Dhaka Division', 'Narshingdi', 'Palash', '2024-04-16 05:43:03', NULL),
(211, 'Dhaka Division', 'Narshingdi', 'Raipura', '2024-04-16 05:43:03', NULL),
(212, 'Dhaka Division', 'Narshingdi', 'Shibpur', '2024-04-16 05:43:03', NULL),
(213, 'Dhaka Division', 'Rajbari', 'Baliakandi', '2024-04-16 05:43:03', NULL),
(214, 'Dhaka Division', 'Rajbari', 'Goalanda', '2024-04-16 05:43:03', NULL),
(215, 'Dhaka Division', 'Rajbari', 'Kalukhali', '2024-04-16 05:43:03', NULL),
(216, 'Dhaka Division', 'Rajbari', 'Pangsha', '2024-04-16 05:43:03', NULL),
(217, 'Dhaka Division', 'Rajbari', 'Rajbari Sadar', '2024-04-16 05:43:03', NULL),
(218, 'Dhaka Division', 'Shariatpur', 'Bhedarganj', '2024-04-16 05:43:03', NULL),
(219, 'Dhaka Division', 'Shariatpur', 'Damuddya', '2024-04-16 05:43:03', NULL),
(220, 'Dhaka Division', 'Shariatpur', 'Goshairhat', '2024-04-16 05:43:03', NULL),
(221, 'Dhaka Division', 'Shariatpur', 'Janjira', '2024-04-16 05:43:03', NULL),
(222, 'Dhaka Division', 'Shariatpur', 'Naria', '2024-04-16 05:43:03', NULL),
(223, 'Dhaka Division', 'Shariatpur', 'Shariatpur Sadar', '2024-04-16 05:43:03', NULL),
(224, 'Dhaka Division', 'Tangail', 'Basail', '2024-04-16 05:43:03', NULL),
(225, 'Dhaka Division', 'Tangail', 'Bhuapur', '2024-04-16 05:43:03', NULL),
(226, 'Dhaka Division', 'Tangail', 'Delduar', '2024-04-16 05:43:03', NULL),
(227, 'Dhaka Division', 'Tangail', 'Dhanbari', '2024-04-16 05:43:03', NULL),
(228, 'Dhaka Division', 'Tangail', 'Ghatail', '2024-04-16 05:43:03', NULL),
(229, 'Dhaka Division', 'Tangail', 'Gopalpur', '2024-04-16 05:43:03', NULL),
(230, 'Dhaka Division', 'Tangail', 'Kalihati', '2024-04-16 05:43:03', NULL),
(231, 'Dhaka Division', 'Tangail', 'Madhupur', '2024-04-16 05:43:03', NULL),
(232, 'Dhaka Division', 'Tangail', 'Mirzapur', '2024-04-16 05:43:03', NULL),
(233, 'Dhaka Division', 'Tangail', 'Nagarpur', '2024-04-16 05:43:03', NULL),
(234, 'Dhaka Division', 'Tangail', 'Shakhipur', '2024-04-16 05:43:03', NULL),
(235, 'Dhaka Division', 'Tangail', 'Tangail Sadar', '2024-04-16 05:43:03', NULL),
(236, 'Khulna Division', 'Bagerhat', 'Bagerhat Sadar', '2024-04-16 05:43:03', NULL),
(237, 'Khulna Division', 'Bagerhat', 'Chitalmari', '2024-04-16 05:43:03', NULL),
(238, 'Khulna Division', 'Bagerhat', 'Fakirhat', '2024-04-16 05:43:03', NULL),
(239, 'Khulna Division', 'Bagerhat', 'Kachua', '2024-04-16 05:43:03', NULL),
(240, 'Khulna Division', 'Bagerhat', 'Mollahat', '2024-04-16 05:43:03', NULL),
(241, 'Khulna Division', 'Bagerhat', 'Mongla', '2024-04-16 05:43:03', NULL),
(242, 'Khulna Division', 'Bagerhat', 'Morrelganj', '2024-04-16 05:43:03', NULL),
(243, 'Khulna Division', 'Bagerhat', 'Rampal', '2024-04-16 05:43:03', NULL),
(244, 'Khulna Division', 'Bagerhat', 'Sharankhola', '2024-04-16 05:43:03', NULL),
(245, 'Khulna Division', 'Chuadanga', 'Alamdanga', '2024-04-16 05:43:03', NULL),
(246, 'Khulna Division', 'Chuadanga', 'Chuadanga Sadar', '2024-04-16 05:43:03', NULL),
(247, 'Khulna Division', 'Chuadanga', 'Damurhuda', '2024-04-16 05:43:03', NULL),
(248, 'Khulna Division', 'Chuadanga', 'Jibannagar', '2024-04-16 05:43:03', NULL),
(249, 'Khulna Division', 'Jashore', 'Abhoynagar', '2024-04-16 05:43:03', NULL),
(250, 'Khulna Division', 'Jashore', 'Bagherpara', '2024-04-16 05:43:03', NULL),
(251, 'Khulna Division', 'Jashore', 'Chowgacha', '2024-04-16 05:43:03', NULL),
(252, 'Khulna Division', 'Jashore', 'Jashore Sadar', '2024-04-16 05:43:03', NULL),
(253, 'Khulna Division', 'Jashore', 'Jhikargacha', '2024-04-16 05:43:03', NULL),
(254, 'Khulna Division', 'Jashore', 'Keshabpur', '2024-04-16 05:43:03', NULL),
(255, 'Khulna Division', 'Jashore', 'Monirampur', '2024-04-16 05:43:03', NULL),
(256, 'Khulna Division', 'Jashore', 'Sarsha', '2024-04-16 05:43:03', NULL),
(257, 'Khulna Division', 'Jhenaidah', 'Harinakunda', '2024-04-16 05:43:03', NULL),
(258, 'Khulna Division', 'Jhenaidah', 'Jhenaidah Sadar', '2024-04-16 05:43:03', NULL),
(259, 'Khulna Division', 'Jhenaidah', 'Kaliganj', '2024-04-16 05:43:03', NULL),
(260, 'Khulna Division', 'Jhenaidah', 'Kotchandpur', '2024-04-16 05:43:03', NULL),
(261, 'Khulna Division', 'Jhenaidah', 'Moheshpur', '2024-04-16 05:43:03', NULL),
(262, 'Khulna Division', 'Jhenaidah', 'Shailkupa', '2024-04-16 05:43:03', NULL),
(263, 'Khulna Division', 'Khulna', 'Batiaghata', '2024-04-16 05:43:03', NULL),
(264, 'Khulna Division', 'Khulna', 'Dacope', '2024-04-16 05:43:03', NULL),
(265, 'Khulna Division', 'Khulna', 'Dighalia', '2024-04-16 05:43:03', NULL),
(266, 'Khulna Division', 'Khulna', 'Dumuria', '2024-04-16 05:43:03', NULL),
(267, 'Khulna Division', 'Khulna', 'Koira', '2024-04-16 05:43:03', NULL),
(268, 'Khulna Division', 'Khulna', 'Paikgacha', '2024-04-16 05:43:03', NULL),
(269, 'Khulna Division', 'Khulna', 'Phultala', '2024-04-16 05:43:03', NULL),
(270, 'Khulna Division', 'Khulna', 'Rupsa', '2024-04-16 05:43:03', NULL),
(271, 'Khulna Division', 'Khulna', 'Terokhada', '2024-04-16 05:43:03', NULL),
(272, 'Khulna Division', 'Kushtia', 'Bheramara', '2024-04-16 05:43:03', NULL),
(273, 'Khulna Division', 'Kushtia', 'Daulatpur', '2024-04-16 05:43:03', NULL),
(274, 'Khulna Division', 'Kushtia', 'Khoksha', '2024-04-16 05:43:03', NULL),
(275, 'Khulna Division', 'Kushtia', 'Kumarkhali', '2024-04-16 05:43:03', NULL),
(276, 'Khulna Division', 'Kushtia', 'Kushtia Sadar', '2024-04-16 05:43:03', NULL),
(277, 'Khulna Division', 'Kushtia', 'Mirpur', '2024-04-16 05:43:03', NULL),
(278, 'Khulna Division', 'Magura', 'Mirpur Sadar', '2024-04-16 05:43:03', NULL),
(279, 'Khulna Division', 'Magura', 'Mohammadpur', '2024-04-16 05:43:03', NULL),
(280, 'Khulna Division', 'Magura', 'Salikha', '2024-04-16 05:43:03', NULL),
(281, 'Khulna Division', 'Magura', 'Sreepur', '2024-04-16 05:43:03', NULL),
(282, 'Khulna Division', 'Meherpur', 'Gangni', '2024-04-16 05:43:03', NULL),
(283, 'Khulna Division', 'Meherpur', 'Meherpur Sadar', '2024-04-16 05:43:03', NULL),
(284, 'Khulna Division', 'Meherpur', 'Mujib Nagar', '2024-04-16 05:43:03', NULL),
(285, 'Khulna Division', 'Narail', 'Kalia', '2024-04-16 05:43:03', NULL),
(286, 'Khulna Division', 'Narail', 'Lohagara', '2024-04-16 05:43:03', NULL),
(287, 'Khulna Division', 'Narail', 'Narail Sadar', '2024-04-16 05:43:03', NULL),
(288, 'Khulna Division', 'Satkhira', 'Assasuni', '2024-04-16 05:43:03', NULL),
(289, 'Khulna Division', 'Satkhira', 'Debhata', '2024-04-16 05:43:03', NULL),
(290, 'Khulna Division', 'Satkhira', 'Kalaroa', '2024-04-16 05:43:03', NULL),
(291, 'Khulna Division', 'Satkhira', 'Kaliganj', '2024-04-16 05:43:03', NULL),
(292, 'Khulna Division', 'Satkhira', 'Satkhira Sadar', '2024-04-16 05:43:03', NULL),
(293, 'Khulna Division', 'Satkhira', 'Shyamnagar', '2024-04-16 05:43:03', NULL),
(294, 'Khulna Division', 'Satkhira', 'Tala', '2024-04-16 05:43:03', NULL),
(295, 'Mymensingh Division', 'Jamalpur', 'Bakshiganj', '2024-04-16 05:43:03', NULL),
(296, 'Mymensingh Division', 'Jamalpur', 'Dewanganj', '2024-04-16 05:43:03', NULL),
(297, 'Mymensingh Division', 'Jamalpur', 'Islampur', '2024-04-16 05:43:03', NULL),
(298, 'Mymensingh Division', 'Jamalpur', 'Jamalpur Sadar', '2024-04-16 05:43:03', NULL),
(299, 'Mymensingh Division', 'Jamalpur', 'Madarganj', '2024-04-16 05:43:03', NULL),
(300, 'Mymensingh Division', 'Jamalpur', 'Melendah', '2024-04-16 05:43:03', NULL),
(301, 'Mymensingh Division', 'Jamalpur', 'Sarishabari', '2024-04-16 05:43:03', NULL),
(302, 'Mymensingh Division', 'Mymensingh', 'Bhaluka', '2024-04-16 05:43:03', NULL),
(303, 'Mymensingh Division', 'Mymensingh', 'Dhobaura', '2024-04-16 05:43:03', NULL),
(304, 'Mymensingh Division', 'Mymensingh', 'Fulbaria', '2024-04-16 05:43:03', NULL),
(305, 'Mymensingh Division', 'Mymensingh', 'Gaffargaon', '2024-04-16 05:43:03', NULL),
(306, 'Mymensingh Division', 'Mymensingh', 'Gouripur', '2024-04-16 05:43:03', NULL),
(307, 'Mymensingh Division', 'Mymensingh', 'Haluaghat', '2024-04-16 05:43:03', NULL),
(308, 'Mymensingh Division', 'Mymensingh', 'Ishwarganj', '2024-04-16 05:43:03', NULL),
(309, 'Mymensingh Division', 'Mymensingh', 'Muktagacha', '2024-04-16 05:43:03', NULL),
(310, 'Mymensingh Division', 'Mymensingh', 'Mymensingh Sadar', '2024-04-16 05:43:03', NULL),
(311, 'Mymensingh Division', 'Mymensingh', 'Nandail', '2024-04-16 05:43:03', NULL),
(312, 'Mymensingh Division', 'Mymensingh', 'Phulpur', '2024-04-16 05:43:03', NULL),
(313, 'Mymensingh Division', 'Mymensingh', 'Tarakanda', '2024-04-16 05:43:03', NULL),
(314, 'Mymensingh Division', 'Mymensingh', 'Trishal', '2024-04-16 05:43:03', NULL),
(315, 'Mymensingh Division', 'Netrokona', 'Atpara', '2024-04-16 05:43:03', NULL),
(316, 'Mymensingh Division', 'Netrokona', 'Barhatta', '2024-04-16 05:43:03', NULL),
(317, 'Mymensingh Division', 'Netrokona', 'Durgapur', '2024-04-16 05:43:03', NULL),
(318, 'Mymensingh Division', 'Netrokona', 'Kalmakanda', '2024-04-16 05:43:03', NULL),
(319, 'Mymensingh Division', 'Netrokona', 'Kendua', '2024-04-16 05:43:03', NULL),
(320, 'Mymensingh Division', 'Netrokona', 'Khaliajuri', '2024-04-16 05:43:03', NULL),
(321, 'Mymensingh Division', 'Netrokona', 'Madan', '2024-04-16 05:43:03', NULL),
(322, 'Mymensingh Division', 'Netrokona', 'Mohanganj', '2024-04-16 05:43:03', NULL),
(323, 'Mymensingh Division', 'Netrokona', 'Netrakona Sadar', '2024-04-16 05:43:03', NULL),
(324, 'Mymensingh Division', 'Netrokona', 'Purbadhala', '2024-04-16 05:43:03', NULL),
(325, 'Mymensingh Division', 'Sherpur', 'Jhenaigati', '2024-04-16 05:43:03', NULL),
(326, 'Mymensingh Division', 'Sherpur', 'Nakla', '2024-04-16 05:43:03', NULL),
(327, 'Mymensingh Division', 'Sherpur', 'Nalitabari', '2024-04-16 05:43:03', NULL),
(328, 'Mymensingh Division', 'Sherpur', 'Sherpur Sadar', '2024-04-16 05:43:03', NULL),
(329, 'Mymensingh Division', 'Sherpur', 'Sreebordi', '2024-04-16 05:43:03', NULL),
(330, 'Rajshahi Division', 'Bogura', 'Adamdighi', '2024-04-16 05:43:03', NULL),
(331, 'Rajshahi Division', 'Bogura', 'Bogura Sadar', '2024-04-16 05:43:03', NULL),
(332, 'Rajshahi Division', 'Bogura', 'Dhunot', '2024-04-16 05:43:03', NULL),
(333, 'Rajshahi Division', 'Bogura', 'Dhupchancia', '2024-04-16 05:43:03', NULL),
(334, 'Rajshahi Division', 'Bogura', 'Gabtali', '2024-04-16 05:43:03', NULL),
(335, 'Rajshahi Division', 'Bogura', 'Kahaloo', '2024-04-16 05:43:03', NULL),
(336, 'Rajshahi Division', 'Bogura', 'Nandigram', '2024-04-16 05:43:03', NULL),
(337, 'Rajshahi Division', 'Bogura', 'Sariakandi', '2024-04-16 05:43:03', NULL),
(338, 'Rajshahi Division', 'Bogura', 'Shajahanpur', '2024-04-16 05:43:03', NULL),
(339, 'Rajshahi Division', 'Bogura', 'Sherpur', '2024-04-16 05:43:03', NULL),
(340, 'Rajshahi Division', 'Bogura', 'Shibganj', '2024-04-16 05:43:03', NULL),
(341, 'Rajshahi Division', 'Bogura', 'Sonatala', '2024-04-16 05:43:03', NULL),
(342, 'Rajshahi Division', 'Chapainawabganj', 'Bholahat', '2024-04-16 05:43:03', NULL),
(343, 'Rajshahi Division', 'Chapainawabganj', 'Gomostapur', '2024-04-16 05:43:03', NULL),
(344, 'Rajshahi Division', 'Chapainawabganj', 'Nachol', '2024-04-16 05:43:03', NULL),
(345, 'Rajshahi Division', 'Chapainawabganj', 'Chapainawabganj Sadar', '2024-04-16 05:43:03', NULL),
(346, 'Rajshahi Division', 'Chapainawabganj', 'Shibganj', '2024-04-16 05:43:03', NULL),
(347, 'Rajshahi Division', 'Joypurhat', 'Akkelpur', '2024-04-16 05:43:03', NULL),
(348, 'Rajshahi Division', 'Joypurhat', 'Joypurhat Sadar', '2024-04-16 05:43:03', NULL),
(349, 'Rajshahi Division', 'Joypurhat', 'Kalai', '2024-04-16 05:43:03', NULL),
(350, 'Rajshahi Division', 'Joypurhat', 'Khetlal', '2024-04-16 05:43:03', NULL),
(351, 'Rajshahi Division', 'Joypurhat', 'Panchbibi', '2024-04-16 05:43:03', NULL),
(352, 'Rajshahi Division', 'Naogaon', 'Atrai', '2024-04-16 05:43:03', NULL),
(353, 'Rajshahi Division', 'Naogaon', 'Badalgachi', '2024-04-16 05:43:03', NULL),
(354, 'Rajshahi Division', 'Naogaon', 'Dhamoirhat', '2024-04-16 05:43:03', NULL),
(355, 'Rajshahi Division', 'Naogaon', 'Manda', '2024-04-16 05:43:03', NULL),
(356, 'Rajshahi Division', 'Naogaon', 'Mohadevpur', '2024-04-16 05:43:03', NULL),
(357, 'Rajshahi Division', 'Naogaon', 'Naogaon Sadar', '2024-04-16 05:43:03', NULL),
(358, 'Rajshahi Division', 'Naogaon', 'Niamatpur', '2024-04-16 05:43:03', NULL),
(359, 'Rajshahi Division', 'Naogaon', 'Patnitala', '2024-04-16 05:43:03', NULL),
(360, 'Rajshahi Division', 'Naogaon', 'Porsha', '2024-04-16 05:43:03', NULL),
(361, 'Rajshahi Division', 'Naogaon', 'Raninagar', '2024-04-16 05:43:03', NULL),
(362, 'Rajshahi Division', 'Naogaon', 'Shapahar', '2024-04-16 05:43:03', NULL),
(363, 'Rajshahi Division', 'Natore', 'Bagatipara', '2024-04-16 05:43:03', NULL),
(364, 'Rajshahi Division', 'Natore', 'Baraigram', '2024-04-16 05:43:03', NULL),
(365, 'Rajshahi Division', 'Natore', 'Gurudaspur', '2024-04-16 05:43:03', NULL),
(366, 'Rajshahi Division', 'Natore', 'Lalpur', '2024-04-16 05:43:03', NULL),
(367, 'Rajshahi Division', 'Natore', 'Naldanga', '2024-04-16 05:43:03', NULL),
(368, 'Rajshahi Division', 'Natore', 'Natore Sadar', '2024-04-16 05:43:03', NULL),
(369, 'Rajshahi Division', 'Natore', 'Singra', '2024-04-16 05:43:03', NULL),
(370, 'Rajshahi Division', 'Pabna', 'Atghoria', '2024-04-16 05:43:03', NULL),
(371, 'Rajshahi Division', 'Pabna', 'Bera', '2024-04-16 05:43:03', NULL),
(372, 'Rajshahi Division', 'Pabna', 'Bhangura', '2024-04-16 05:43:03', NULL),
(373, 'Rajshahi Division', 'Pabna', 'Chatmohar', '2024-04-16 05:43:03', NULL),
(374, 'Rajshahi Division', 'Pabna', 'Faridpur', '2024-04-16 05:43:03', NULL),
(375, 'Rajshahi Division', 'Pabna', 'Ishwardi', '2024-04-16 05:43:03', NULL),
(376, 'Rajshahi Division', 'Pabna', 'Pabna Sadar', '2024-04-16 05:43:03', NULL),
(377, 'Rajshahi Division', 'Pabna', 'Santhia', '2024-04-16 05:43:03', NULL),
(378, 'Rajshahi Division', 'Pabna', 'Sujanagar', '2024-04-16 05:43:03', NULL),
(379, 'Rajshahi Division', 'Rajshahi', 'Bagha', '2024-04-16 05:43:03', NULL),
(380, 'Rajshahi Division', 'Rajshahi', 'Bagmara', '2024-04-16 05:43:03', NULL),
(381, 'Rajshahi Division', 'Rajshahi', 'Charghat', '2024-04-16 05:43:03', NULL),
(382, 'Rajshahi Division', 'Rajshahi', 'Durgapur', '2024-04-16 05:43:03', NULL),
(383, 'Rajshahi Division', 'Rajshahi', 'Godagari', '2024-04-16 05:43:03', NULL),
(384, 'Rajshahi Division', 'Rajshahi', 'Mohanpur', '2024-04-16 05:43:03', NULL),
(385, 'Rajshahi Division', 'Rajshahi', 'Paba', '2024-04-16 05:43:03', NULL),
(386, 'Rajshahi Division', 'Rajshahi', 'Puthia', '2024-04-16 05:43:03', NULL),
(387, 'Rajshahi Division', 'Rajshahi', 'Tanore', '2024-04-16 05:43:03', NULL),
(388, 'Rajshahi Division', 'Sirajganj', 'Belkuchi', '2024-04-16 05:43:03', NULL),
(389, 'Rajshahi Division', 'Sirajganj', 'Chowhali', '2024-04-16 05:43:03', NULL),
(390, 'Rajshahi Division', 'Sirajganj', 'Kamarkhand', '2024-04-16 05:43:03', NULL),
(391, 'Rajshahi Division', 'Sirajganj', 'Kazipur', '2024-04-16 05:43:03', NULL),
(392, 'Rajshahi Division', 'Sirajganj', 'Raiganj', '2024-04-16 05:43:03', NULL),
(393, 'Rajshahi Division', 'Sirajganj', 'Shahzadpur', '2024-04-16 05:43:03', NULL),
(394, 'Rajshahi Division', 'Sirajganj', 'Sirajganj Sadar', '2024-04-16 05:43:03', NULL),
(395, 'Rajshahi Division', 'Sirajganj', 'Tarash', '2024-04-16 05:43:03', NULL),
(396, 'Rajshahi Division', 'Sirajganj', 'Ullapara', '2024-04-16 05:43:03', NULL),
(397, 'Rangpur Division', 'Dinajpur', 'Birampur', '2024-04-16 05:43:03', NULL),
(398, 'Rangpur Division', 'Dinajpur', 'Birganj', '2024-04-16 05:43:03', NULL),
(399, 'Rangpur Division', 'Dinajpur', 'Birol', '2024-04-16 05:43:03', NULL),
(400, 'Rangpur Division', 'Dinajpur', 'Bochaganj', '2024-04-16 05:43:03', NULL),
(401, 'Rangpur Division', 'Dinajpur', 'Chirirbandar', '2024-04-16 05:43:03', NULL),
(402, 'Rangpur Division', 'Dinajpur', 'Dinajpur Sadar', '2024-04-16 05:43:03', NULL),
(403, 'Rangpur Division', 'Dinajpur', 'Fulbari', '2024-04-16 05:43:03', NULL),
(404, 'Rangpur Division', 'Dinajpur', 'Ghoraghat', '2024-04-16 05:43:03', NULL),
(405, 'Rangpur Division', 'Dinajpur', 'Hakimpur', '2024-04-16 05:43:03', NULL),
(406, 'Rangpur Division', 'Dinajpur', 'Kaharol', '2024-04-16 05:43:03', NULL),
(407, 'Rangpur Division', 'Dinajpur', 'Khanshama', '2024-04-16 05:43:03', NULL),
(408, 'Rangpur Division', 'Dinajpur', 'Nawabganj', '2024-04-16 05:43:03', NULL),
(409, 'Rangpur Division', 'Dinajpur', 'Parbatipur', '2024-04-16 05:43:03', NULL),
(410, 'Rangpur Division', 'Gaibandha', 'Fulchari', '2024-04-16 05:43:03', NULL),
(411, 'Rangpur Division', 'Gaibandha', 'Gaibandha Sadar', '2024-04-16 05:43:03', NULL),
(412, 'Rangpur Division', 'Gaibandha', 'Gobindaganj', '2024-04-16 05:43:03', NULL),
(413, 'Rangpur Division', 'Gaibandha', 'Palashbari', '2024-04-16 05:43:03', NULL),
(414, 'Rangpur Division', 'Gaibandha', 'Sadullapur', '2024-04-16 05:43:03', NULL),
(415, 'Rangpur Division', 'Gaibandha', 'Saghata', '2024-04-16 05:43:03', NULL),
(416, 'Rangpur Division', 'Gaibandha', 'Sundarganj', '2024-04-16 05:43:03', NULL),
(417, 'Rangpur Division', 'Kurigram', 'Bhurungamari', '2024-04-16 05:43:03', NULL),
(418, 'Rangpur Division', 'Kurigram', 'Chilmari', '2024-04-16 05:43:03', NULL),
(419, 'Rangpur Division', 'Kurigram', 'Fulbari', '2024-04-16 05:43:03', NULL),
(420, 'Rangpur Division', 'Kurigram', 'Kurigram Sadar', '2024-04-16 05:43:03', NULL),
(421, 'Rangpur Division', 'Kurigram', 'Nageswari', '2024-04-16 05:43:03', NULL),
(422, 'Rangpur Division', 'Kurigram', 'Rajarhat', '2024-04-16 05:43:03', NULL),
(423, 'Rangpur Division', 'Kurigram', 'Rajibpur', '2024-04-16 05:43:03', NULL),
(424, 'Rangpur Division', 'Kurigram', 'Rowmari', '2024-04-16 05:43:03', NULL),
(425, 'Rangpur Division', 'Kurigram', 'Ulipur', '2024-04-16 05:43:03', NULL),
(426, 'Rangpur Division', 'Lalmonirhat', 'Aditmari', '2024-04-16 05:43:03', NULL),
(427, 'Rangpur Division', 'Lalmonirhat', 'Hatibandha', '2024-04-16 05:43:03', NULL),
(428, 'Rangpur Division', 'Lalmonirhat', 'Kaliganj', '2024-04-16 05:43:03', NULL),
(429, 'Rangpur Division', 'Lalmonirhat', 'Lalmonirhat Sadar', '2024-04-16 05:43:03', NULL),
(430, 'Rangpur Division', 'Lalmonirhat', 'Patgram', '2024-04-16 05:43:03', NULL),
(431, 'Rangpur Division', 'Nilphamari', 'Dimla', '2024-04-16 05:43:03', NULL),
(432, 'Rangpur Division', 'Nilphamari', 'Domar', '2024-04-16 05:43:03', NULL),
(433, 'Rangpur Division', 'Nilphamari', 'Jaldhaka', '2024-04-16 05:43:03', NULL),
(434, 'Rangpur Division', 'Nilphamari', 'Kishoreganj', '2024-04-16 05:43:03', NULL),
(435, 'Rangpur Division', 'Nilphamari', 'Nilphamari Sadar', '2024-04-16 05:43:03', NULL),
(436, 'Rangpur Division', 'Panchagarh', 'Sayedpur', '2024-04-16 05:43:03', NULL),
(437, 'Rangpur Division', 'Panchagarh', 'Atwari', '2024-04-16 05:43:03', NULL),
(438, 'Rangpur Division', 'Panchagarh', 'Boda', '2024-04-16 05:43:03', NULL),
(439, 'Rangpur Division', 'Panchagarh', 'Debiganj', '2024-04-16 05:43:03', NULL),
(440, 'Rangpur Division', 'Panchagarh', 'Panchagarh Sadar', '2024-04-16 05:43:03', NULL),
(441, 'Rangpur Division', 'Panchagarh', 'Tetulia', '2024-04-16 05:43:03', NULL),
(442, 'Rangpur Division', 'Rangpur', 'Badarganj', '2024-04-16 05:43:03', NULL),
(443, 'Rangpur Division', 'Rangpur', 'Gangachara', '2024-04-16 05:43:03', NULL),
(444, 'Rangpur Division', 'Rangpur', 'Kaunia', '2024-04-16 05:43:03', NULL),
(445, 'Rangpur Division', 'Rangpur', 'Mithapukur', '2024-04-16 05:43:03', NULL),
(446, 'Rangpur Division', 'Rangpur', 'Pirgacha', '2024-04-16 05:43:03', NULL),
(447, 'Rangpur Division', 'Rangpur', 'Pirganj', '2024-04-16 05:43:03', NULL),
(448, 'Rangpur Division', 'Rangpur', 'Rangpur Sadar', '2024-04-16 05:43:03', NULL),
(449, 'Rangpur Division', 'Rangpur', 'Taraganj', '2024-04-16 05:43:03', NULL),
(450, 'Rangpur Division', 'Thakurgaon', 'Baliadangi', '2024-04-16 05:43:03', NULL),
(451, 'Rangpur Division', 'Thakurgaon', 'Haripur', '2024-04-16 05:43:03', NULL),
(452, 'Rangpur Division', 'Thakurgaon', 'Pirganj', '2024-04-16 05:43:03', NULL),
(453, 'Rangpur Division', 'Thakurgaon', 'Ranisankail', '2024-04-16 05:43:03', NULL),
(454, 'Rangpur Division', 'Thakurgaon', 'Thakurgaon Sadar', '2024-04-16 05:43:03', NULL),
(455, 'Sylhet Division', 'Habiganj', 'Azmiriganj', '2024-04-16 05:43:03', NULL),
(456, 'Sylhet Division', 'Habiganj', 'Bahubal', '2024-04-16 05:43:03', NULL),
(457, 'Sylhet Division', 'Habiganj', 'Baniachong', '2024-04-16 05:43:03', NULL),
(458, 'Sylhet Division', 'Habiganj', 'Chunarughat', '2024-04-16 05:43:03', NULL),
(459, 'Sylhet Division', 'Habiganj', 'Habiganj Sadar', '2024-04-16 05:43:03', NULL),
(460, 'Sylhet Division', 'Habiganj', 'Lakhai', '2024-04-16 05:43:03', NULL),
(461, 'Sylhet Division', 'Habiganj', 'Madhabpur', '2024-04-16 05:43:03', NULL),
(462, 'Sylhet Division', 'Habiganj', 'Nabiganj', '2024-04-16 05:43:03', NULL),
(463, 'Sylhet Division', 'Habiganj', 'Sayestaganj', '2024-04-16 05:43:03', NULL),
(464, 'Sylhet Division', 'Moulvibazar', 'Barlekha', '2024-04-16 05:43:03', NULL),
(465, 'Sylhet Division', 'Moulvibazar', 'Juri', '2024-04-16 05:43:03', NULL),
(466, 'Sylhet Division', 'Moulvibazar', 'Kamalganj', '2024-04-16 05:43:03', NULL),
(467, 'Sylhet Division', 'Moulvibazar', 'Kulaura', '2024-04-16 05:43:03', NULL),
(468, 'Sylhet Division', 'Moulvibazar', 'Moulvibazar Sadar', '2024-04-16 05:43:03', NULL),
(469, 'Sylhet Division', 'Moulvibazar', 'Rajnagar', '2024-04-16 05:43:03', NULL),
(470, 'Sylhet Division', 'Moulvibazar', 'Sreemangal', '2024-04-16 05:43:03', NULL),
(471, 'Sylhet Division', 'Sunamganj', 'Biswamvarpur', '2024-04-16 05:43:03', NULL),
(472, 'Sylhet Division', 'Sunamganj', 'Chatak', '2024-04-16 05:43:03', NULL),
(473, 'Sylhet Division', 'Sunamganj', 'Dakhin Sunamganj', '2024-04-16 05:43:03', NULL),
(474, 'Sylhet Division', 'Sunamganj', 'Derai', '2024-04-16 05:43:03', NULL),
(475, 'Sylhet Division', 'Sunamganj', 'Dharmapasha', '2024-04-16 05:43:03', NULL),
(476, 'Sylhet Division', 'Sunamganj', 'Doarabazar', '2024-04-16 05:43:03', NULL),
(477, 'Sylhet Division', 'Sunamganj', 'Jagannathpur', '2024-04-16 05:43:03', NULL),
(478, 'Sylhet Division', 'Sunamganj', 'Jamalganj', '2024-04-16 05:43:03', NULL),
(479, 'Sylhet Division', 'Sunamganj', 'Sulla', '2024-04-16 05:43:03', NULL),
(480, 'Sylhet Division', 'Sunamganj', 'Sunamganj Sadar', '2024-04-16 05:43:03', NULL),
(481, 'Sylhet Division', 'Sunamganj', 'Tahirpur', '2024-04-16 05:43:03', NULL),
(482, 'Sylhet Division', 'Sylhet', 'Balaganj', '2024-04-16 05:43:03', NULL),
(483, 'Sylhet Division', 'Sylhet', 'Beanibazar', '2024-04-16 05:43:03', NULL),
(484, 'Sylhet Division', 'Sylhet', 'Biswanath', '2024-04-16 05:43:03', NULL),
(485, 'Sylhet Division', 'Sylhet', 'Companiganj', '2024-04-16 05:43:03', NULL),
(486, 'Sylhet Division', 'Sylhet', 'Dakshin Surma', '2024-04-16 05:43:03', NULL),
(487, 'Sylhet Division', 'Sylhet', 'Fenchuganj', '2024-04-16 05:43:03', NULL),
(488, 'Sylhet Division', 'Sylhet', 'Golapganj', '2024-04-16 05:43:03', NULL),
(489, 'Sylhet Division', 'Sylhet', 'Gowainghat', '2024-04-16 05:43:03', NULL),
(490, 'Sylhet Division', 'Sylhet', 'Jointiapur', '2024-04-16 05:43:03', NULL),
(491, 'Sylhet Division', 'Sylhet', 'Kanaighat', '2024-04-16 05:43:03', NULL),
(492, 'Sylhet Division', 'Sylhet', 'Osmaninagar', '2024-04-16 05:43:03', NULL),
(493, 'Sylhet Division', 'Sylhet', 'Sylhet Sadar', '2024-04-16 05:43:03', NULL),
(494, 'Sylhet Division', 'Sylhet', 'Zakiganj', '2024-04-16 05:43:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(2, '2024_02_07_110642_create_location_infos_table', 1),
(3, '2024_02_07_110716_create_department_infos_table', 1),
(4, '2024_02_07_110945_create_designations_table', 1),
(5, '2024_02_08_100606_create_transaction__withs_table', 1),
(6, '2024_02_11_081701_create_user__infos_table', 1),
(7, '2024_02_11_083248_create_transaction__groupes_table', 1),
(8, '2024_02_11_083256_create_transaction__heads_table', 1),
(9, '2024_02_12_061130_create_transaction__details_table', 1),
(10, '2024_02_12_072956_create_transaction__mains_table', 1),
(11, '2024_02_19_113033_create_party__payment__receives_table', 1),
(12, '2024_03_06_115612_create_admins_table', 1),
(13, '2024_03_27_064809_create_attendences_table', 1),
(14, '2024_03_28_060905_create_pay__roll__setups_table', 1),
(15, '2024_04_06_092440_create_personal_details_table', 1),
(16, '2024_04_06_093252_create_education_details_table', 1),
(17, '2024_04_06_170752_create_training_details_table', 1),
(18, '2024_04_06_170948_create_experience_details_table', 1),
(19, '2024_04_06_171144_create_joining_details_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `party__payment__receives`
--

CREATE TABLE `party__payment__receives` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tran_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loc_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tran_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tran_type_with` bigint(20) UNSIGNED DEFAULT NULL,
  `tran_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tran_groupe_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tran_head_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` double(8,2) NOT NULL DEFAULT 1.00,
  `bill_amount` double(8,2) NOT NULL,
  `discount` double(8,2) NOT NULL DEFAULT 0.00,
  `net_amount` double(8,2) NOT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `rem_due` double(8,2) NOT NULL DEFAULT 0.00,
  `party_amount` double(8,2) DEFAULT NULL,
  `party_tran_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tran_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `party__payment__receives`
--

INSERT INTO `party__payment__receives` (`id`, `tran_id`, `invoice`, `loc_id`, `tran_type`, `tran_type_with`, `tran_user`, `tran_groupe_id`, `tran_head_id`, `quantity`, `bill_amount`, `discount`, `net_amount`, `amount`, `rem_due`, `party_amount`, `party_tran_id`, `tran_date`, `updated_at`) VALUES
(1, 'PR00000001', NULL, 330, 'receive', 5, 'C000000101', 4, 23, 1.00, 14800.00, 0.00, 14800.00, 7000.00, 7800.00, 7000.00, 'R000000001', '2024-04-17 09:37:25', NULL),
(2, 'PR00000002', NULL, 330, 'receive', 5, 'C000000101', 4, 23, 1.00, 7800.00, 300.00, 7500.00, 2000.00, 5500.00, 2000.00, 'R000000001', '2024-04-17 09:39:20', NULL),
(3, 'PR00000003', NULL, 330, 'receive', 4, 'C000000102', 4, 23, 1.00, 10000.00, 0.00, 10000.00, 3000.00, 7000.00, 3000.00, 'R000000002', '2024-04-17 09:39:42', NULL),
(4, 'PP00000001', NULL, 330, 'payment', 7, 'S000000101', 4, 15, 1.00, 198800.00, 2000.00, 196800.00, 48000.00, 148800.00, 48000.00, 'P000000001', '2024-04-17 09:50:24', NULL),
(5, 'PP00000002', NULL, 330, 'payment', 8, 'S000000102', 4, 15, 1.00, 26000.00, 400.00, 25600.00, 8000.00, 17600.00, 8000.00, 'P000000002', '2024-04-17 09:51:18', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `pay__roll__setups`
--

CREATE TABLE `pay__roll__setups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `emp_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `head_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double(8,2) NOT NULL,
  `date` date DEFAULT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_details`
--

CREATE TABLE `personal_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `employee_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fathers_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mothers_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_of_birth` date NOT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `religion` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `marital_status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nationality` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phn_no` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `blood_group` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` blob DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `personal_details`
--

INSERT INTO `personal_details` (`id`, `employee_id`, `name`, `fathers_name`, `mothers_name`, `date_of_birth`, `gender`, `religion`, `marital_status`, `nationality`, `phn_no`, `blood_group`, `email`, `address`, `image`, `created_at`, `updated_at`) VALUES
(1, 'E000000101', 'Shagufta', 'Md. Sajid', 'Shahela Jabbar', '2002-07-28', 'female', 'Islam', 'Unmarried', 'bangladesh', '01767940630', 'AB+', 'ssajid3421@gmail.com', 'Shewrapara', 0x433a5c78616d70705c746d705c706870443534412e746d70, NULL, NULL),
(2, 'E000000102', 'Fardin', 'Zakir Hossen', 'Romana Akter', '2002-03-27', 'male', 'Islam', 'Unmarried', 'bangladesh', '01940630654', 'A+', 'ahsannje@gmail.comtgr', 'Kazipara', 0x433a5c78616d70705c746d705c706870374342372e746d70, NULL, NULL),
(5, 'E000000105', 'sufi', 'wadud', 'moni', '2002-09-22', 'male', 'islam', 'Unmarried', 'bangladesh', '01585454756', 'B+', 'sufi@gmail.com', 'Farmgate', 0x433a5c78616d70705c746d705c706870364535322e746d70, NULL, NULL),
(6, 'E000000106', 'Shahela', 'Md. Jabbar', 'Suroor Fatema', '1976-04-24', 'female', 'Islam', 'Married', 'Bangladeshi', '01940630654', 'AB+', 'shahela@gmail.com', 'Cumilla', 0x433a5c78616d70705c746d705c7068704430302e746d70, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `training_details`
--

CREATE TABLE `training_details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `emp_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `training_title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `topic` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `institution_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `training_year` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `training_details`
--

INSERT INTO `training_details` (`id`, `emp_id`, `training_title`, `country`, `topic`, `institution_name`, `start_date`, `end_date`, `training_year`, `created_at`, `updated_at`) VALUES
(1, 'E000000101', 'Computer', 'Bangladesh', 'Programming', 'IPSC', '2022-02-22', '2023-02-23', 2020, NULL, NULL),
(2, 'E000000102', 'Testing', 'Bangladesh', 'Automation Testing', 'BCIC', '2022-06-22', '2022-11-24', 2024, NULL, NULL),
(5, 'E000000105', 'Computer', 'Bangladesh', 'Security', 'Monipur', '2021-06-21', '2021-07-13', 2015, NULL, NULL),
(6, 'E000000106', 'Spoken English language', 'Bangladesh', 'English language', 'Women College', '2010-05-10', '2010-12-10', 1995, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction__details`
--

CREATE TABLE `transaction__details` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tran_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loc_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tran_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tran_type_with` bigint(20) UNSIGNED DEFAULT NULL,
  `tran_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tran_groupe_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tran_head_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` double(8,2) DEFAULT NULL,
  `amount` double(8,2) DEFAULT NULL,
  `tot_amount` double(8,2) DEFAULT NULL,
  `tran_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transaction__details`
--

INSERT INTO `transaction__details` (`id`, `tran_id`, `invoice`, `loc_id`, `tran_type`, `tran_type_with`, `tran_user`, `tran_groupe_id`, `tran_head_id`, `quantity`, `amount`, `tot_amount`, `tran_date`, `updated_at`) VALUES
(1, 'R000000001', '6786', 330, 'receive', 5, 'C000000101', 3, 22, 1.00, 10000.00, 10000.00, '2024-04-17 09:34:07', NULL),
(2, 'R000000001', '6786', 330, 'receive', 5, 'C000000101', 3, 21, 1.00, 10000.00, 10000.00, '2024-04-17 09:34:22', NULL),
(3, 'R000000002', '6786', 7, 'receive', 4, 'C000000102', 3, 20, 1.00, 10000.00, 10000.00, '2024-04-17 09:35:59', NULL),
(4, 'R000000002', '6786', 7, 'receive', 4, 'C000000102', 3, 19, 1.00, 5000.00, 5000.00, '2024-04-17 09:36:06', NULL),
(5, 'P000000001', '5445', 330, 'payment', 7, 'S000000101', 2, 12, 1.00, 8000.00, 8000.00, '2024-04-17 09:45:03', NULL),
(6, 'P000000001', '5445', 330, 'payment', 7, 'S000000101', 2, 14, 28.00, 7000.00, 196000.00, '2024-04-17 09:45:29', NULL),
(7, 'P000000002', '5445', 249, 'payment', 8, 'S000000102', 2, 12, 5.00, 2000.00, 10000.00, '2024-04-17 09:46:35', NULL),
(8, 'P000000002', '5445', 249, 'payment', 8, 'S000000102', 2, 13, 1000.00, 30.00, 30000.00, '2024-04-17 09:46:49', NULL),
(9, 'P000000003', '6786', 426, 'payment', 12, 'S000000103', 5, 25, 5.00, 35.00, 175.00, '2024-04-17 10:00:40', NULL),
(10, 'P000000003', '6786', 426, 'payment', 12, 'S000000103', 5, 43, 12.00, 100.00, 1200.00, '2024-04-17 10:01:02', NULL),
(11, 'P000000003', '6786', 426, 'payment', 12, 'S000000103', 5, 42, 5.00, 350.00, 1750.00, '2024-04-17 10:01:20', NULL),
(12, 'P000000004', '6786', 330, 'payment', 12, 'S000000103', 5, 27, 4.00, 2000.00, 8000.00, '2024-04-18 10:04:53', NULL),
(13, 'P000000004', '6786', 330, 'payment', 12, 'S000000103', 5, 28, 5.00, 40.00, 200.00, '2024-04-18 10:05:09', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction__groupes`
--

CREATE TABLE `transaction__groupes` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tran_groupe_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tran_groupe_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transaction__groupes`
--

INSERT INTO `transaction__groupes` (`id`, `tran_groupe_name`, `tran_groupe_type`, `added_at`, `updated_at`) VALUES
(1, 'Salary', 'Payment', '2024-04-16 05:43:03', NULL),
(2, 'Printing Tools', 'Payment', '2024-04-16 05:43:03', NULL),
(3, 'Advertisement', 'Receive', '2024-04-16 05:43:03', NULL),
(4, 'Party Payment And Receive', 'Both', '2024-04-16 05:43:03', NULL),
(5, 'Kitchen', 'Payment', '2024-04-16 05:43:03', '2024-04-17 03:59:44'),
(6, 'Supplier', 'Payment', '2024-04-16 05:43:03', NULL),
(7, 'Client', 'Receive', '2024-04-16 05:43:03', NULL),
(8, 'Utility', 'Payment', '2024-04-16 05:43:03', NULL),
(9, 'Stationary', 'Invoice', '2024-04-16 05:43:03', NULL),
(10, 'Miscellaneous', 'Payment', '2024-04-16 05:43:03', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction__heads`
--

CREATE TABLE `transaction__heads` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tran_head_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `groupe_id` bigint(20) UNSIGNED NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transaction__heads`
--

INSERT INTO `transaction__heads` (`id`, `tran_head_name`, `groupe_id`, `added_at`, `updated_at`) VALUES
(1, 'Basic', 1, '2024-04-16 05:43:03', NULL),
(2, 'House Rent', 1, '2024-04-16 05:43:03', NULL),
(3, 'Medical', 1, '2024-04-16 05:43:03', NULL),
(4, 'TA/DA', 1, '2024-04-16 05:43:03', NULL),
(5, 'Mobile', 1, '2024-04-16 05:43:03', NULL),
(6, 'Incentive', 1, '2024-04-16 05:43:03', NULL),
(7, 'Eid-Ul-Fitar Bonus', 1, '2024-04-16 05:43:03', NULL),
(8, 'Eid-Ul-Azha Bonus', 1, '2024-04-16 05:43:03', NULL),
(9, 'Provident Fund', 1, '2024-04-16 05:43:03', NULL),
(10, 'Gratuity', 1, '2024-04-16 05:43:03', NULL),
(11, 'Increament', 1, '2024-04-16 05:43:03', NULL),
(12, 'Color Touner', 2, '2024-04-16 05:43:03', NULL),
(13, 'Printing Paper', 2, '2024-04-16 05:43:03', NULL),
(14, 'Printing Colors', 2, '2024-04-16 05:43:03', NULL),
(15, '1 Inch Add', 3, '2024-04-16 05:43:03', NULL),
(16, '2 Inch Add', 3, '2024-04-16 05:43:03', NULL),
(17, '4 Inch Add', 3, '2024-04-16 05:43:03', NULL),
(18, 'Half Page Add', 3, '2024-04-16 05:43:03', NULL),
(19, 'Full Page Add', 3, '2024-04-16 05:43:03', NULL),
(20, '1 Col Add', 3, '2024-04-16 05:43:03', NULL),
(21, '2 Col Add', 3, '2024-04-16 05:43:03', NULL),
(22, '4 Col Add', 3, '2024-04-16 05:43:03', NULL),
(23, 'Receive from client', 4, '2024-04-16 05:43:03', NULL),
(24, 'Payment To Supplier', 4, '2024-04-16 05:43:03', NULL),
(25, 'Alu', 5, '2024-04-16 05:43:03', NULL),
(26, 'Potol', 5, '2024-04-16 05:43:03', NULL),
(27, 'Korola', 5, '2024-04-16 05:43:03', NULL),
(28, 'Jhinga', 5, '2024-04-16 05:43:03', NULL),
(29, 'Gas Bill', 8, '2024-04-16 05:43:03', NULL),
(30, 'Water Bill', 8, '2024-04-16 05:43:03', NULL),
(31, 'Electricity Bill', 8, '2024-04-16 05:43:03', NULL),
(32, 'Telephone Bill', 8, '2024-04-16 05:43:03', NULL),
(33, 'Transportation Bill', 8, '2024-04-16 05:43:03', NULL),
(34, 'Furniture Bill', 8, '2024-04-16 05:43:03', NULL),
(35, 'Pen', 9, '2024-04-16 05:43:03', NULL),
(36, 'Paper', 9, '2024-04-16 05:43:03', NULL),
(37, 'Marker', 9, '2024-04-16 05:43:03', NULL),
(38, 'Duster', 9, '2024-04-16 05:43:03', NULL),
(39, 'Pencil', 9, '2024-04-16 05:43:03', NULL),
(40, 'Stapler', 9, '2024-04-16 05:43:03', NULL),
(41, 'Chal', 5, '2024-04-17 09:57:36', NULL),
(42, 'Tel', 5, '2024-04-17 09:57:42', NULL),
(43, 'aata', 5, '2024-04-17 09:57:49', NULL),
(44, 'Vegetable', 5, '2024-04-17 09:57:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction__mains`
--

CREATE TABLE `transaction__mains` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tran_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loc_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tran_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `bill_amount` double(8,2) DEFAULT NULL,
  `discount` double(8,2) NOT NULL DEFAULT 0.00,
  `net_amount` double(8,2) DEFAULT NULL,
  `receive` double(8,2) DEFAULT NULL,
  `payment` double(8,2) DEFAULT NULL,
  `due` double(8,2) DEFAULT NULL,
  `tran_type_with` bigint(20) UNSIGNED DEFAULT NULL,
  `tran_user` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `due_col` double(8,2) DEFAULT 0.00,
  `due_disc` double(8,2) DEFAULT 0.00,
  `tran_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transaction__mains`
--

INSERT INTO `transaction__mains` (`id`, `tran_id`, `invoice`, `loc_id`, `tran_type`, `bill_amount`, `discount`, `net_amount`, `receive`, `payment`, `due`, `tran_type_with`, `tran_user`, `due_col`, `due_disc`, `tran_date`, `updated_at`) VALUES
(1, 'R000000001', '6786', 330, 'receive', 20000.00, 200.00, 19800.00, 5000.00, NULL, 5500.00, 5, 'C000000101', 9000.00, 300.00, '2024-04-17 09:34:39', '2024-04-17 03:39:20'),
(2, 'R000000002', '6786', 7, 'receive', 15000.00, 200.00, 14800.00, 4800.00, NULL, 7000.00, 4, 'C000000102', 3000.00, 0.00, '2024-04-17 09:36:19', '2024-04-17 03:39:42'),
(3, 'P000000001', '5445', 330, 'payment', 204000.00, 200.00, 203800.00, NULL, 5000.00, 148800.00, 7, 'S000000101', 48000.00, 2000.00, '2024-04-17 09:45:50', '2024-04-17 03:50:24'),
(4, 'P000000002', '5445', 249, 'payment', 40000.00, 2000.00, 38000.00, NULL, 12000.00, 17600.00, 8, 'S000000102', 8000.00, 400.00, '2024-04-17 09:47:09', '2024-04-17 03:51:18'),
(5, 'P000000003', '6786', 426, 'payment', 3125.00, 0.00, 3125.00, NULL, 3125.00, 0.00, 12, 'S000000103', 0.00, 0.00, '2024-04-17 10:01:59', NULL),
(6, 'P000000004', '6786', 330, 'payment', 8200.00, 0.00, 8200.00, NULL, 0.00, 8200.00, 12, 'S000000103', 0.00, 0.00, '2024-04-18 10:05:11', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `transaction__withs`
--

CREATE TABLE `transaction__withs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tran_with_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `transaction__withs`
--

INSERT INTO `transaction__withs` (`id`, `tran_with_name`, `user_type`, `added_at`, `updated_at`) VALUES
(1, 'Regular Employee', 'Employee', '2024-04-16 05:43:03', NULL),
(2, 'Bit Pion', 'Employee', '2024-04-16 05:43:03', NULL),
(3, 'District Employee', 'Employee', '2024-04-16 05:43:03', NULL),
(4, 'Advertisement Client', 'Client', '2024-04-16 05:43:03', NULL),
(5, 'Bank Client', 'Client', '2024-04-16 05:43:03', NULL),
(6, 'Newspaper Client', 'Client', '2024-04-16 05:43:03', NULL),
(7, 'Printing tools Supplier', 'Supplier', '2024-04-16 05:43:03', NULL),
(8, 'Neewspaper Supplier', 'Supplier', '2024-04-16 05:43:03', NULL),
(9, 'Food Supplier', 'Supplier', '2024-04-16 05:43:03', NULL),
(10, 'Stationary Supplier', 'Supplier', '2024-04-16 05:43:03', NULL),
(11, 'Bank', 'Bank', '2024-04-16 05:43:03', NULL),
(12, 'General Supplier', 'Supplier', '2024-04-17 09:54:45', NULL),
(13, 'General Client', 'Client', '2024-04-17 09:54:57', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user__infos`
--

CREATE TABLE `user__infos` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `loc_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tran_user_type` bigint(20) UNSIGNED DEFAULT NULL,
  `dept_id` bigint(20) UNSIGNED DEFAULT NULL,
  `designation_id` bigint(20) UNSIGNED DEFAULT NULL,
  `dob` date DEFAULT NULL,
  `nid` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '1 for Active 0 for Inactive',
  `added_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user__infos`
--

INSERT INTO `user__infos` (`id`, `user_id`, `user_name`, `user_email`, `user_phone`, `gender`, `loc_id`, `user_type`, `tran_user_type`, `dept_id`, `designation_id`, `dob`, `nid`, `address`, `image`, `status`, `added_at`, `updated_at`) VALUES
(1, 'E000000101', 'Shagufta', 'ssajid3421@gmail.com', '01856715365', 'female', 7, 'employee', 1, 2, 1, '2001-07-28', '5475685876', 'shewrapara', 'E000000101(Shagufta).jpg', 0, '2024-04-16 09:20:09', NULL),
(2, 'C000000101', 'Sufi', 'sufi@gmail.com', '0156735765', 'male', 7, 'client', 5, NULL, NULL, NULL, NULL, 'shewrapara', NULL, 0, '2024-04-17 09:30:48', NULL),
(3, 'C000000102', 'Shagufta', 'ssaji54651@gmail.com', '0185671532786', 'male', 330, 'client', 4, NULL, NULL, NULL, NULL, 'shewrapara', NULL, 0, '2024-04-17 09:35:18', NULL),
(4, 'S000000101', 'hasib', 'hasib@gmail.com', '01678736', 'male', 152, 'supplier', 7, NULL, NULL, NULL, NULL, 'shewrapara', NULL, 0, '2024-04-17 09:43:51', NULL),
(5, 'S000000102', 'hasan', 'hasan@gmail.com', '0136576567', 'male', 7, 'supplier', 8, NULL, NULL, NULL, NULL, 'shewraparano', NULL, 0, '2024-04-17 09:44:27', NULL),
(6, 'S000000103', 'Fardin', 'ahsannje@gmail.comtgr', '092767856', 'male', 249, 'supplier', 12, NULL, NULL, NULL, NULL, 'shewrapara', NULL, 0, '2024-04-17 09:55:49', NULL);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `admins_email_unique` (`email`);

--
-- Indexes for table `attendences`
--
ALTER TABLE `attendences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `department__infos`
--
ALTER TABLE `department__infos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `designations`
--
ALTER TABLE `designations`
  ADD PRIMARY KEY (`id`),
  ADD KEY `designations_dept_id_foreign` (`dept_id`);

--
-- Indexes for table `education_details`
--
ALTER TABLE `education_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `education_details_emp_id_foreign` (`emp_id`);

--
-- Indexes for table `experience_details`
--
ALTER TABLE `experience_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `experience_details_emp_id_foreign` (`emp_id`);

--
-- Indexes for table `joining_details`
--
ALTER TABLE `joining_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `joining_details_emp_id_foreign` (`emp_id`);

--
-- Indexes for table `location__infos`
--
ALTER TABLE `location__infos`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `party__payment__receives`
--
ALTER TABLE `party__payment__receives`
  ADD PRIMARY KEY (`id`),
  ADD KEY `party__payment__receives_loc_id_foreign` (`loc_id`),
  ADD KEY `party__payment__receives_tran_type_with_foreign` (`tran_type_with`),
  ADD KEY `party__payment__receives_tran_groupe_id_foreign` (`tran_groupe_id`),
  ADD KEY `party__payment__receives_tran_head_id_foreign` (`tran_head_id`),
  ADD KEY `party__payment__receives_tran_user_foreign` (`tran_user`);

--
-- Indexes for table `pay__roll__setups`
--
ALTER TABLE `pay__roll__setups`
  ADD PRIMARY KEY (`id`),
  ADD KEY `pay__roll__setups_emp_id_foreign` (`emp_id`);

--
-- Indexes for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

--
-- Indexes for table `personal_details`
--
ALTER TABLE `personal_details`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_details_employee_id_unique` (`employee_id`);

--
-- Indexes for table `training_details`
--
ALTER TABLE `training_details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `training_details_emp_id_foreign` (`emp_id`);

--
-- Indexes for table `transaction__details`
--
ALTER TABLE `transaction__details`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction__details_loc_id_foreign` (`loc_id`),
  ADD KEY `transaction__details_tran_type_with_foreign` (`tran_type_with`),
  ADD KEY `transaction__details_tran_groupe_id_foreign` (`tran_groupe_id`),
  ADD KEY `transaction__details_tran_head_id_foreign` (`tran_head_id`),
  ADD KEY `transaction__details_tran_user_foreign` (`tran_user`);

--
-- Indexes for table `transaction__groupes`
--
ALTER TABLE `transaction__groupes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `transaction__heads`
--
ALTER TABLE `transaction__heads`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction__heads_groupe_id_foreign` (`groupe_id`);

--
-- Indexes for table `transaction__mains`
--
ALTER TABLE `transaction__mains`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transaction__mains_loc_id_foreign` (`loc_id`),
  ADD KEY `transaction__mains_tran_type_with_foreign` (`tran_type_with`),
  ADD KEY `transaction__mains_tran_user_foreign` (`tran_user`);

--
-- Indexes for table `transaction__withs`
--
ALTER TABLE `transaction__withs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user__infos`
--
ALTER TABLE `user__infos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `user__infos_user_id_unique` (`user_id`),
  ADD UNIQUE KEY `user__infos_user_email_unique` (`user_email`),
  ADD UNIQUE KEY `user__infos_user_phone_unique` (`user_phone`),
  ADD KEY `user__infos_loc_id_foreign` (`loc_id`),
  ADD KEY `user__infos_dept_id_foreign` (`dept_id`),
  ADD KEY `user__infos_designation_id_foreign` (`designation_id`),
  ADD KEY `user__infos_tran_user_type_foreign` (`tran_user_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `attendences`
--
ALTER TABLE `attendences`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `department__infos`
--
ALTER TABLE `department__infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `designations`
--
ALTER TABLE `designations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `education_details`
--
ALTER TABLE `education_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `experience_details`
--
ALTER TABLE `experience_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `joining_details`
--
ALTER TABLE `joining_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `location__infos`
--
ALTER TABLE `location__infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=495;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `party__payment__receives`
--
ALTER TABLE `party__payment__receives`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `pay__roll__setups`
--
ALTER TABLE `pay__roll__setups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_access_tokens`
--
ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `personal_details`
--
ALTER TABLE `personal_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `training_details`
--
ALTER TABLE `training_details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transaction__details`
--
ALTER TABLE `transaction__details`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `transaction__groupes`
--
ALTER TABLE `transaction__groupes`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `transaction__heads`
--
ALTER TABLE `transaction__heads`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

--
-- AUTO_INCREMENT for table `transaction__mains`
--
ALTER TABLE `transaction__mains`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `transaction__withs`
--
ALTER TABLE `transaction__withs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `user__infos`
--
ALTER TABLE `user__infos`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `designations`
--
ALTER TABLE `designations`
  ADD CONSTRAINT `designations_dept_id_foreign` FOREIGN KEY (`dept_id`) REFERENCES `department__infos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `education_details`
--
ALTER TABLE `education_details`
  ADD CONSTRAINT `education_details_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `personal_details` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `experience_details`
--
ALTER TABLE `experience_details`
  ADD CONSTRAINT `experience_details_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `personal_details` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `joining_details`
--
ALTER TABLE `joining_details`
  ADD CONSTRAINT `joining_details_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `personal_details` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `party__payment__receives`
--
ALTER TABLE `party__payment__receives`
  ADD CONSTRAINT `party__payment__receives_loc_id_foreign` FOREIGN KEY (`loc_id`) REFERENCES `location__infos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `party__payment__receives_tran_groupe_id_foreign` FOREIGN KEY (`tran_groupe_id`) REFERENCES `transaction__groupes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `party__payment__receives_tran_head_id_foreign` FOREIGN KEY (`tran_head_id`) REFERENCES `transaction__heads` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `party__payment__receives_tran_type_with_foreign` FOREIGN KEY (`tran_type_with`) REFERENCES `transaction__withs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `party__payment__receives_tran_user_foreign` FOREIGN KEY (`tran_user`) REFERENCES `user__infos` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `pay__roll__setups`
--
ALTER TABLE `pay__roll__setups`
  ADD CONSTRAINT `pay__roll__setups_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `user__infos` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `training_details`
--
ALTER TABLE `training_details`
  ADD CONSTRAINT `training_details_emp_id_foreign` FOREIGN KEY (`emp_id`) REFERENCES `personal_details` (`employee_id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaction__details`
--
ALTER TABLE `transaction__details`
  ADD CONSTRAINT `transaction__details_loc_id_foreign` FOREIGN KEY (`loc_id`) REFERENCES `location__infos` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `transaction__details_tran_groupe_id_foreign` FOREIGN KEY (`tran_groupe_id`) REFERENCES `transaction__groupes` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `transaction__details_tran_head_id_foreign` FOREIGN KEY (`tran_head_id`) REFERENCES `transaction__heads` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `transaction__details_tran_type_with_foreign` FOREIGN KEY (`tran_type_with`) REFERENCES `transaction__withs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `transaction__details_tran_user_foreign` FOREIGN KEY (`tran_user`) REFERENCES `user__infos` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `transaction__heads`
--
ALTER TABLE `transaction__heads`
  ADD CONSTRAINT `transaction__heads_groupe_id_foreign` FOREIGN KEY (`groupe_id`) REFERENCES `transaction__groupes` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transaction__mains`
--
ALTER TABLE `transaction__mains`
  ADD CONSTRAINT `transaction__mains_loc_id_foreign` FOREIGN KEY (`loc_id`) REFERENCES `location__infos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transaction__mains_tran_type_with_foreign` FOREIGN KEY (`tran_type_with`) REFERENCES `transaction__withs` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `transaction__mains_tran_user_foreign` FOREIGN KEY (`tran_user`) REFERENCES `user__infos` (`user_id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `user__infos`
--
ALTER TABLE `user__infos`
  ADD CONSTRAINT `user__infos_dept_id_foreign` FOREIGN KEY (`dept_id`) REFERENCES `department__infos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user__infos_designation_id_foreign` FOREIGN KEY (`designation_id`) REFERENCES `designations` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user__infos_loc_id_foreign` FOREIGN KEY (`loc_id`) REFERENCES `location__infos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `user__infos_tran_user_type_foreign` FOREIGN KEY (`tran_user_type`) REFERENCES `transaction__withs` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
